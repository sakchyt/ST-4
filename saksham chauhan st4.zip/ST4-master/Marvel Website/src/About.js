import React from 'react'

const About = () => {
  return (
    <div className = 'aboutspace'>
          
           <h1>WE ARE TRYING TO TELL INFORMATION ABOUT MARVEL CHARACTERS </h1>
           <h1>MARVEL ARE THE BEST WE EVER SEEN . SO WE TRIED TO MAKE A REACT APP SO THAT WE CAN LEARN MORE ABOUT EACH CHARACTER.</h1>     

    </div>
  )
}

export default About